package com.example.egzamin2; //https://github.com/marcinserwer

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int licznik = 0;
    TextView Licznik;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @SuppressLint("SetTextI18n")
    public void Polub(View view) {
        Licznik = findViewById(R.id.Licznik); //Znajduje dany obiekt i przypisuje go do zmiennej
        licznik++; //Dodaje jeden do licznika
        Licznik.setText(licznik+" polubień"); //Ustawia tekst
    }

    @SuppressLint("SetTextI18n")
    public void Usun(View view) {
        Licznik = findViewById(R.id.Licznik); //Znajduje dany obiekt i przypisuje go do zmiennej
        if(licznik != 0){ //Jeśli licznik jest różny od zera
            licznik--; //Odejmuje jeden od licznika
            Licznik.setText(licznik+" polubień"); //Ustawia tekst
        }
    }
}