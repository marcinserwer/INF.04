package com.example.galeriazdjec; /* https://github.com/marcinserwer */ //60 STRONA W INFORMATORZE

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int IdZdjecia = 1;
    String NazwaZdjecia;
    ImageView Zdjecie;

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Zdjecie = findViewById(R.id.imageView); //Wyszukanie ImageView
        
        EditText poleID = findViewById(R.id.editTextNumber); //Wyszukanie inputa
        poleID.setOnKeyListener((view, keyCode, keyEvent) -> { //Jeśli kliknięto przycisk na klawiaturze
            if(keyCode == KeyEvent.KEYCODE_ENTER){ //Jeśli kliknięty przycisk to ENTER
                int NumerZInputa = Integer.parseInt(poleID.getText().toString()); //Pobiera numer z inputa
                if(NumerZInputa >= 1 && NumerZInputa <= 4){ //(Nie ma tego w wymaganiach) Jeśli numer wynosi od 1 do 4
                    NazwaZdjecia = "kot" + NumerZInputa; //Tworzenie nazwy zdjęcia
                    int imageId = getResources().getIdentifier(NazwaZdjecia, "drawable", getPackageName()); //Tworzenie nazwy dla zdjęcia (Trzeba przekształcić na int)
                    Zdjecie.setImageResource(imageId); //Ustawia zdjęcie, (Przyjmuje tylko wartości int)
                }else{ //Jeśli nie wynosi od 1 do 4
                    Toast.makeText(MainActivity.this, "Nie ma takiego obrazka", Toast.LENGTH_SHORT).show();
                }
            }
            return false;
        });

        SwitchCompat przelacznik = findViewById(R.id.SwitchChangeBackground); //Wyszukanie switch
        ConstraintLayout ConstraintLayout = findViewById(R.id.ConstraintLayout); //Wyszukanie tła
        przelacznik.setOnCheckedChangeListener((buttonView, isChecked) -> { //Funkcja nadsłuchująca zmiany w switch'u
            if(isChecked){ //Jeśli jest zaznaczony
                ConstraintLayout.setBackgroundColor(ContextCompat.getColor(MainActivity.this, R.color.blue)); //Ustawia kolor "blue" z "colors.xml"
            }else{ //Jeśli nie jest zaznaczony
                ConstraintLayout.setBackgroundColor(ContextCompat.getColor(MainActivity.this, R.color.main)); //Ustawia kolor "main" z "colors.xml"
            }
        });

    }

    public void prev(View view) { //Funkcja przycisku Prev
        if(IdZdjecia > 1){ //Jeśli zdjęcie jest większe od 1
            --IdZdjecia; //Zmniejsza indeks
            NazwaZdjecia = "kot" + IdZdjecia; //Tworzenie nowej nazwy zdjęcia
            int imageId = getResources().getIdentifier(NazwaZdjecia, "drawable", getPackageName()); //Tworzenie nazwy dla zdjęcia (Trzeba przekształcić na int)
            Zdjecie.setImageResource(imageId); //Ustawia zdjęcie, (Przyjmuje tylko wartości int)
        }
    }

    public void next(View view) { //Funkcja przycisku Next
        if(IdZdjecia < 4){ //Jeśli zdjęcie jest mniejsze od 4
            ++IdZdjecia; //Zmniejsza indeks
            NazwaZdjecia = "kot" + IdZdjecia; //Tworzenie nowej nazwy zdjęcia
            int imageId = getResources().getIdentifier(NazwaZdjecia, "drawable", getPackageName()); //Tworzenie nazwy dla zdjęcia (Trzeba przekształcić na int)
            Zdjecie.setImageResource(imageId); //Ustawia zdjęcie, (Przyjmuje tylko wartości int)
        }
    }

}