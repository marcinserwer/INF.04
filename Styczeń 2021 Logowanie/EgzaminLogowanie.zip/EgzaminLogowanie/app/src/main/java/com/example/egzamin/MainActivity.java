package com.example.egzamin; //https://github.com/marcinserwer

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View view) {
        EditText editTextTextEmailAddress = findViewById(R.id.editTextTextEmailAddress); //Znajduje dany obiekt i przypisuje go do zmiennej
        String email_input = editTextTextEmailAddress.getText().toString(); //Pobiera text z "txtname" i przypisuje do zmiennej  "email_input"

        EditText editTextTextPassword2 = findViewById(R.id.editTextTextPassword2); //Znajduje dany obiekt i przypisuje go do zmiennej
        String password1_input = editTextTextPassword2.getText().toString(); //Pobiera text z "txtname1" i przypisuje do zmiennej  "password1_input"

        EditText editTextTextPassword3 = findViewById(R.id.editTextTextPassword3); //Znajduje dany obiekt i przypisuje go do zmiennej
        String password2_input = editTextTextPassword3.getText().toString(); //Pobiera text z "txtname2" i przypisuje do zmiennej  "password2_input"

        TextView Result = findViewById(R.id.Result); //Znajduje dany obiekt i przypisuje go do zmiennej

        if(!email_input.contains("@")){ //Contains - czy zawiera (zwraca true lub false)
            Result.setText("Nieprawidłowy adres e-mail"); //Ustawia tekst
        }else if(!password1_input.equals(password2_input)){ //!zmienna.equals(zmienna) odpowiednik !==
            Result.setText("Hasła się różnią"); //Ustawia tekst
        }else{
            Result.setText("Witaj "+email_input); //Ustawia tekst
        }
    }
}