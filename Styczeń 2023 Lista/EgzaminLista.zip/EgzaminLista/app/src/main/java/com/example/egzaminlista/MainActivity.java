package com.example.egzaminlista; //https://github.com/marcinserwer

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    ArrayList<String> ListaNotatek;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listview); //Wyszukanie i przypisanie listy widoku
        ListaNotatek = new ArrayList<>(Arrays.asList(getResources().getStringArray(R.array.Lista))); //Wyszukanie i przypisanie listy z strings.xml

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.textview, R.id.textView2, ListaNotatek); //Stworzenie adapteru z ListaNotatek i textView2 (Jest to każdy poszczególny wiersz w liście, monzą to ostylować w textview.xml)
        listView.setAdapter(adapter); //Ustawienie adaptera

        listView.setOnItemClickListener((adapterView, view, i, l) -> { //Reakcja na kliknięcie elementu listy
            String value = adapter.getItem(i); //Pobranie wartości klikniętego elementu
            Toast.makeText(MainActivity.this, value, Toast.LENGTH_SHORT).show(); //Wyświetlenie komunikatu Toast z wartością klikniętego elementu
        });
    }

    public void Dodanie(View view) { //Przycisk "DODAJ"
        EditText InputEditText = findViewById(R.id.editText); //Wyszukanie i przypisanie inputa
        String stringElement = InputEditText.getText().toString().trim(); // Pobieranie tekstu z pola tekstowego i usuwanie początkowych i końcowych białych znaków

        if (!stringElement.isEmpty()) { //Sprawdzanie, czy pole tekstowe nie jest puste
            ListaNotatek.add(stringElement); //Dodawanie elementu do listy notatek

            listView = findViewById(R.id.listview); //Wyszukanie i przypisanie listy widoku
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.textview, R.id.textView2, ListaNotatek); //Stworzenie adapteru z ListaNotatek i textView2 (Jest to każdy poszczególny wiersz w liście, monzą to ostylować w textview.xml)
            listView.setAdapter(adapter); //Ustawienie adaptera

            InputEditText.setText(""); //Czyszczenie zawartości inputa
        }
    }
}
